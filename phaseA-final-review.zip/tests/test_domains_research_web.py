import json
import os

import httpx
import pytest

from anticassiopeia.core import Claim
from anticassiopeia.core.verdict import Evidence
from anticassiopeia.domains.research_web import _MAX_RESPONSE_BYTES, ResearchWebAdapter, _is_near_duplicate_evidence, _safe_fetch
from anticassiopeia.llm.nebius_client import NebiusClientError
from evals.fixture_server import serve_fixtures

# `block_private_networks=False` below (only on tests that fetch this file's own
# local fixture server, 127.0.0.1) opts out of the SSRF guard added to
# research_web.py's real fetch calls -- see that module's docstring for the fix
# and why this is the ONLY place it's legitimate to disable it; default_domains()
# (what the real server uses) never does.


class _DummyAsyncClient:
    def __init__(self, response: httpx.Response):
        self._response = response

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def get(self, url: str) -> httpx.Response:
        return self._response

    async def aclose(self) -> None:
        return None

    def stream(self, method: str, url: str, headers: dict | None = None) -> "_DummyStream":
        return _DummyStream(self._response)


class _DummyStream:
    """Matches the subset of httpx's `client.stream(...)` async-context-manager
    interface _safe_fetch() actually uses (status_code/headers/aiter_bytes) --
    needed once research_web.py switched from client.get() to client.stream()
    to support manual per-hop redirect re-validation (see that module's
    _safe_fetch docstring)."""

    def __init__(self, response: httpx.Response):
        self._response = response

    async def __aenter__(self) -> httpx.Response:
        return self._response

    async def __aexit__(self, exc_type, exc, tb):
        return False


async def test_block_page_200_is_treated_as_undetermined_not_contradicted(monkeypatch):
    request = httpx.Request("GET", "https://example.com")
    response = httpx.Response(
        200,
        request=request,
        text="<html><body><h1>Access Denied</h1><p>Blocked by policy proxy.</p></body></html>",
    )
    monkeypatch.setattr(httpx, "AsyncClient", lambda **_: _DummyAsyncClient(response))

    adapter = ResearchWebAdapter()
    claim = Claim(
        text="example.com states it is reserved for illustrative examples",
        domain="research_web",
        context={"url": "https://example.com", "quote": "illustrative examples in documents"},
    )
    ev = await adapter.gather_evidence(claim)

    assert ev == []
    gap = adapter.describe_gap(claim, ev)
    assert "block/proxy page" in gap[0]


async def test_non_block_page_without_quote_is_real_contradiction(monkeypatch):
    request = httpx.Request("GET", "https://example.com")
    response = httpx.Response(200, request=request, text="<html><body><p>ordinary page text</p></body></html>")
    monkeypatch.setattr(httpx, "AsyncClient", lambda **_: _DummyAsyncClient(response))

    adapter = ResearchWebAdapter()
    claim = Claim(
        text="example.com states it is reserved for illustrative examples",
        domain="research_web",
        context={"url": "https://example.com", "quote": "illustrative examples in documents"},
    )
    ev = await adapter.gather_evidence(claim)

    assert len(ev) == 1
    assert ev[0].stance == "contradicts"


class _NetworkCallAttempted(AssertionError):
    """Raised if anything tries to actually open a connection -- used below to
    prove the SSRF guard rejects an unsafe URL BEFORE any network call, not
    just eventually via a failed fetch."""


def _forbid_network_calls(monkeypatch) -> None:
    """Patches the actual request-issuing method, not just AsyncClient's
    constructor -- _safe_fetch() legitimately constructs a client lazily
    AFTER confirming the first hop is safe, so asserting "no client was ever
    constructed" would be the wrong (too strict, implementation-specific)
    claim; asserting "no request was ever issued" is the real property that
    matters and stays true regardless of internal client-construction timing."""

    def _raise(*_args, **_kwargs):
        raise _NetworkCallAttempted("httpx.AsyncClient.stream was called -- the SSRF guard did not short-circuit first.")

    monkeypatch.setattr(httpx.AsyncClient, "stream", _raise)


@pytest.mark.parametrize(
    "unsafe_url",
    [
        "http://169.254.169.254/latest/meta-data/",  # cloud metadata endpoint (link-local)
        "http://localhost/",
        "http://127.0.0.1/",
        "http://10.0.0.5/",  # RFC1918 private range
    ],
)
async def test_ssrf_guard_rejects_unsafe_url_before_any_network_call_mode1(monkeypatch, unsafe_url):
    """FOUND BUG (external security review): research_web.py fetched ANY url
    handed to it in Claim.context with zero validation -- SSRF. Fixed via
    _is_safe_to_fetch(). This proves the fix for mode 1 (ctx["url"], fully
    caller-supplied) and proves the rejection happens BEFORE any network
    call is attempted, not just that the eventual fetch fails."""
    _forbid_network_calls(monkeypatch)
    adapter = ResearchWebAdapter()
    claim = Claim(
        text="x", domain="research_web",
        context={"url": unsafe_url, "quote": "anything"},
    )
    ev = await adapter.gather_evidence(claim)
    assert ev == []
    gap = adapter.describe_gap(claim, ev)
    assert "refused to fetch" in gap[0].lower()


async def test_ssrf_guard_rejects_unsafe_url_before_any_network_call_mode2(monkeypatch):
    """Same guard, mode 2 (multi-candidate): a search backend that returns an
    internal URL as a "candidate" must not get it fetched either -- the
    guard applies uniformly, not just to the directly caller-supplied url."""
    _forbid_network_calls(monkeypatch)

    async def fake_search(_query: str, _max: int) -> list[str]:
        return ["http://169.254.169.254/latest/meta-data/"]

    adapter = ResearchWebAdapter(search=fake_search)
    claim = Claim(text="some claim with no url in context", domain="research_web")
    ev = await adapter.gather_evidence(claim)
    assert ev == []


async def test_ssrf_guard_catches_a_redirect_to_an_unsafe_address_not_just_the_original_url(monkeypatch):
    """FOUND BUG (follow-up security review): the first version of this guard
    checked only the ORIGINAL url, then fetched with follow_redirects=True --
    a url that passes the check could still 302-redirect straight to an
    internal address with no second check. Simulates exactly that: a public-
    looking first hop (passes _is_safe_to_fetch) that 302s to the cloud
    metadata endpoint. Must be rejected at the redirect hop, not followed."""
    call_count = {"n": 0}

    class _RedirectOnceStream:
        def __init__(self, response: httpx.Response):
            self._response = response

        async def __aenter__(self) -> httpx.Response:
            return self._response

        async def __aexit__(self, exc_type, exc, tb):
            return False

    def _fake_stream(self, method, url, headers=None):
        call_count["n"] += 1
        if call_count["n"] == 1:
            # A real, legitimate-looking first hop -- passes _is_safe_to_fetch
            # (example.com is a real public address) -- then redirects.
            resp = httpx.Response(
                302,
                headers={"Location": "http://169.254.169.254/latest/meta-data/"},
                request=httpx.Request(method, url),
            )
            return _RedirectOnceStream(resp)
        raise AssertionError("the redirect target was followed without being re-checked -- SSRF-via-redirect bypass")

    monkeypatch.setattr(httpx.AsyncClient, "stream", _fake_stream)

    adapter = ResearchWebAdapter()
    claim = Claim(
        text="x", domain="research_web",
        context={"url": "https://example.com/looks-fine", "quote": "anything"},
    )
    ev = await adapter.gather_evidence(claim)
    assert ev == []
    gap = adapter.describe_gap(claim, ev)
    assert "refused to fetch" in gap[0].lower()
    assert call_count["n"] == 1  # the redirect target was checked and rejected, never fetched


async def test_safe_fetch_caps_response_body_at_the_documented_limit(monkeypatch):
    """FOUND BUG (follow-up security review): resp.text loaded the entire
    response body into memory with no cap -- an oversized (or malicious)
    response could exhaust server memory. _safe_fetch() now streams and
    stops at _MAX_RESPONSE_BYTES; proves it actually truncates, not just
    that the constant exists."""
    oversized = b"x" * (_MAX_RESPONSE_BYTES + 1000)

    class _OversizedStream:
        status_code = 200
        headers = httpx.Headers({"content-type": "text/plain"})
        request = httpx.Request("GET", "https://example.com/huge")

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        async def aiter_bytes(self):
            # Yield in chunks, like a real streamed response would.
            chunk_size = 64 * 1024
            for i in range(0, len(oversized), chunk_size):
                yield oversized[i : i + chunk_size]

    monkeypatch.setattr(httpx.AsyncClient, "stream", lambda self, method, url, headers=None: _OversizedStream())

    resp = await _safe_fetch("https://example.com/huge")
    assert len(resp.content) == _MAX_RESPONSE_BYTES


# --- mode 2: multi-candidate live search, tested offline via a fake search provider
# that points at the real local fixture server (same fixtures/web/ pages mode 1 uses)
# plus a scripted fake LLM client, so the REAL propose()->verify_proposal() pipeline
# runs over a real local HTTP fetch without any network/live-key dependency. ---


class _FakeClient:
    """Test double for NebiusTokenFactoryClient covering BOTH prompt shapes this
    adapter sends: a propose() JSON-extraction prompt (starts "Question: ") and a
    _judge_stance() one-word prompt (starts "CLAIM: ").

    `propose_response` is the default answer for any propose() prompt.
    `propose_by_marker`, if given, picks a DIFFERENT answer per source when the
    prompt contains a given substring (e.g. a chunk_id prefix unique to one
    fetched page) — needed for tests with more than one distinct source."""

    def __init__(
        self,
        propose_response: str | Exception = "",
        stance_response: str = "supports",
        propose_by_marker: dict[str, str | Exception] | None = None,
    ):
        self._propose_response = propose_response
        self._stance_response = stance_response
        self._propose_by_marker = propose_by_marker or {}

    async def complete(self, prompt: str, *, system: str | None = None, temperature: float = 0.0) -> str:
        if prompt.startswith("CLAIM:"):
            return self._stance_response
        for marker, response in self._propose_by_marker.items():
            if marker in prompt:
                if isinstance(response, Exception):
                    raise response
                return response
        if isinstance(self._propose_response, Exception):
            raise self._propose_response
        return self._propose_response


def _found_json(chunk_id: str, quote: str) -> str:
    return json.dumps({"found": True, "chunk_id": chunk_id, "quote": quote, "value": None, "unit": None, "kind": None})


_NOT_FOUND_JSON = json.dumps({"found": False, "reason": "not stated in the shown passages"})
_FIXTURE_QUOTE = "The reference pump is rated for a maximum operating pressure of 12 bar."


async def test_multi_candidate_confirmed_through_real_fixture_fetch_and_verify():
    """A real HTTP fetch of a local fixture page, real chunking, real BM25, the real
    propose()->verify_proposal() pipeline, and a scripted stance judgment — the only
    fake things are the search-candidate list (points at the fixture server instead
    of the live web) and the LLM client (no network/key needed)."""
    with serve_fixtures() as base_url:

        async def fake_search(_query: str, _max: int) -> list[str]:
            return [f"{base_url}/stable_page.html"]

        # chunk_id = f"{doc_id}#0": this tiny page's stripped text is one chunk,
        # and doc_id is the fetched URL itself — verified via chunk_document's
        # own documented id scheme, not guessed.
        client = _FakeClient(_found_json(f"{base_url}/stable_page.html#0", _FIXTURE_QUOTE), stance_response="supports")
        adapter = ResearchWebAdapter(client=client, search=fake_search, block_private_networks=False)
        claim = Claim(text="the reference pump is rated for a maximum operating pressure of 12 bar", domain="research_web")
        ev = await adapter.gather_evidence(claim)

    assert len(ev) == 1
    assert ev[0].stance == "supports"
    assert ev[0].source == f"{base_url}/stable_page.html"
    assert "chunk" in ev[0].locator


async def test_multi_candidate_contradicted_when_model_judges_conflict():
    with serve_fixtures() as base_url:

        async def fake_search(_query: str, _max: int) -> list[str]:
            return [f"{base_url}/stable_page.html"]

        client = _FakeClient(
            _found_json(f"{base_url}/stable_page.html#0", _FIXTURE_QUOTE), stance_response="contradicts"
        )
        adapter = ResearchWebAdapter(client=client, search=fake_search, block_private_networks=False)
        claim = Claim(text="the reference pump is rated for 9999 bar", domain="research_web")
        ev = await adapter.gather_evidence(claim)

    assert len(ev) == 1
    assert ev[0].stance == "contradicts"


async def test_multi_candidate_no_candidates_found_is_a_named_gap():
    async def fake_search(_query: str, _max: int) -> list[str]:
        return []

    adapter = ResearchWebAdapter(client=_FakeClient(_NOT_FOUND_JSON), search=fake_search, block_private_networks=False)
    claim = Claim(text="some claim no search backend will find anything for", domain="research_web")
    ev = await adapter.gather_evidence(claim)

    assert ev == []
    gap = adapter.describe_gap(claim, ev)
    assert "no live candidate pages found" in gap[0].lower()


async def test_multi_candidate_model_honestly_reports_not_found_is_undetermined_not_contradicted():
    """The fact genuinely isn't on the fetched page — the model must say so, and
    that must NOT collapse into a false 'contradicts'."""
    with serve_fixtures() as base_url:

        async def fake_search(_query: str, _max: int) -> list[str]:
            return [f"{base_url}/stable_page.html"]

        adapter = ResearchWebAdapter(client=_FakeClient(_NOT_FOUND_JSON), search=fake_search, block_private_networks=False)
        claim = Claim(text="the reference pump has a maximum operating pressure of 12 bar", domain="research_web")
        ev = await adapter.gather_evidence(claim)

    assert ev == []
    gap = adapter.describe_gap(claim, ev)
    assert "honestly reported" in gap[0]


async def test_multi_candidate_fabricated_quote_is_rejected_even_with_a_real_candidate_page():
    """The core property, carried over to mode 2: a quote that is NOT actually on
    the real fetched page must be rejected by verify_proposal(), regardless of
    what the (fake, scripted) proposer claims."""
    with serve_fixtures() as base_url:

        async def fake_search(_query: str, _max: int) -> list[str]:
            return [f"{base_url}/stable_page.html"]

        client = _FakeClient(_found_json(f"{base_url}/stable_page.html#0", "maximum operating pressure of 9999 bar"))
        adapter = ResearchWebAdapter(client=client, search=fake_search, block_private_networks=False)
        claim = Claim(text="the reference pump is rated for a maximum operating pressure of 12 bar", domain="research_web")
        ev = await adapter.gather_evidence(claim)

    assert ev == [], "a quote that does not exist in the real fetched page must never become Evidence"


async def test_multi_candidate_missing_key_is_a_named_gap_not_a_crash(monkeypatch):
    """NEBIUS_API_KEY missing entirely must surface as a specific, honest gap —
    reached only after a real fetch + real BM25 match, so this exercises the
    client-missing branch for real, not in isolation."""
    monkeypatch.delenv("NEBIUS_API_KEY", raising=False)

    with serve_fixtures() as base_url:

        async def fake_search(_query: str, _max: int) -> list[str]:
            return [f"{base_url}/stable_page.html"]

        adapter = ResearchWebAdapter(search=fake_search, block_private_networks=False)  # no client injected, no key in env
        claim = Claim(
            text="the reference pump is rated for a maximum operating pressure of 12 bar", domain="research_web"
        )
        ev = await adapter.gather_evidence(claim)

    assert ev == []
    gap = adapter.describe_gap(claim, ev)
    assert "propose step can't run" in gap[0]
    assert "NEBIUS_API_KEY" in gap[0]


async def test_multi_candidate_propose_failure_is_a_named_gap_not_a_crash():
    with serve_fixtures() as base_url:

        async def fake_search(_query: str, _max: int) -> list[str]:
            return [f"{base_url}/stable_page.html"]

        failing = NebiusClientError('Nebius Token Factory returned 401: {"detail": "..."}')
        adapter = ResearchWebAdapter(client=_FakeClient(failing), search=fake_search, block_private_networks=False)
        claim = Claim(text="the reference pump is rated for a maximum operating pressure of 12 bar", domain="research_web")
        ev = await adapter.gather_evidence(claim)

    assert ev == []
    gap = adapter.describe_gap(claim, ev)
    assert "propose call failed" in gap[0]
    assert "401" in gap[0]


# --- live tests: require a real, working NEBIUS_API_KEY and real network access.
# Skipped (not run) when the var is entirely unset; FAIL for real (not skip) if the
# var is set but something's actually broken — same policy as robotics.py's live
# tests, same reasoning: a configured-but-broken key/search/model is a fact worth
# surfacing, not hiding. Each outcome below was independently confirmed live,
# repeatedly, before being written down here — see research_web.py's module
# docstring and evals/cases/research_web/live_multi_candidate_*.json. ---

_requires_live_key = pytest.mark.skipif(
    not os.environ.get("NEBIUS_API_KEY"), reason="requires a real, working NEBIUS_API_KEY"
)


@_requires_live_key
async def test_live_multi_candidate_confirmed_from_a_real_wikipedia_article():
    adapter = ResearchWebAdapter()
    claim = Claim(
        text="BlueROV2 is a modular remotely operated underwater vehicle developed by Blue Robotics",
        domain="research_web",
    )
    ev = await adapter.gather_evidence(claim)
    assert ev, f"expected real confirmed evidence; gap: {getattr(adapter, '_last_web_gap', None)}"
    assert ev[0].stance == "supports"
    assert ev[0].source == "https://en.wikipedia.org/wiki/BlueROV2"


@_requires_live_key
async def test_live_multi_candidate_contradicted_by_a_real_wikipedia_article():
    adapter = ResearchWebAdapter()
    claim = Claim(text="BlueROV2 was developed by OpenROV", domain="research_web")
    ev = await adapter.gather_evidence(claim)
    assert ev, f"expected real contradicting evidence; gap: {getattr(adapter, '_last_web_gap', None)}"
    assert ev[0].stance == "contradicts"


@_requires_live_key
async def test_live_multi_candidate_undetermined_when_no_real_source_settles_it():
    """A specific, plausible-sounding, fabricated-style number that no real
    source actually states — must stay UNDETERMINED, never a guessed CONFIRMED."""
    adapter = ResearchWebAdapter()
    claim = Claim(
        text="Blue Robotics Bar30 pressure sensor has a mean time between failures of 50000 hours",
        domain="research_web",
    )
    ev = await adapter.gather_evidence(claim)
    assert ev == [], f"expected no evidence (honest gap), got: {ev}"
    gap = adapter.describe_gap(claim, ev)
    assert "no live candidate pages found" in gap[0].lower()


# --- near-duplicate evidence guard: two near-identical sources (a mirror, or a
# page that copy-pasted the same sentence) must not both count as independent
# confirmation; two genuinely different sources confirming the same real-world
# fact must still both count, since that's real corroboration, not redundancy. ---


def test_is_near_duplicate_evidence_true_for_near_identical_quotes():
    a = Evidence(source="https://mirror-a.example/page", snippet=_FIXTURE_QUOTE, stance="supports", trust=0.75)
    b = Evidence(source="https://mirror-b.example/page", snippet=_FIXTURE_QUOTE, stance="supports", trust=0.75)
    assert _is_near_duplicate_evidence(a, b)


def test_is_near_duplicate_evidence_false_for_genuinely_different_quotes():
    a = Evidence(source="https://site-a.example/page", snippet=_FIXTURE_QUOTE, stance="supports", trust=0.75)
    b = Evidence(
        source="https://site-b.example/page",
        snippet="An independent test report confirmed the reference pump operates safely up to 12 bar without failure.",
        stance="supports",
        trust=0.75,
    )
    assert not _is_near_duplicate_evidence(a, b)


def test_is_near_duplicate_evidence_false_for_empty_text():
    a = Evidence(source="https://a.example", snippet="", stance="supports", trust=0.75)
    b = Evidence(source="https://b.example", snippet="", stance="supports", trust=0.75)
    assert not _is_near_duplicate_evidence(a, b)


async def test_multi_candidate_mirror_sources_count_as_one_not_two():
    """PROVES the fix matters: two different URLs serving byte-identical content
    (a mirror site, simulated here via a harmless query-string variant of the
    same real fixture page) must resolve to exactly ONE piece of Evidence, not
    two — engine.py's trust-weighted sum must not see this as double the real
    confirmation it actually has."""
    with serve_fixtures() as base_url:
        url_a = f"{base_url}/stable_page.html?mirror=1"
        url_b = f"{base_url}/stable_page.html?mirror=2"

        async def fake_search(_query: str, _max: int) -> list[str]:
            return [url_a, url_b]

        client = _FakeClient(
            propose_by_marker={
                f"{url_a}#0": _found_json(f"{url_a}#0", _FIXTURE_QUOTE),
                f"{url_b}#0": _found_json(f"{url_b}#0", _FIXTURE_QUOTE),
            }
        )
        adapter = ResearchWebAdapter(client=client, search=fake_search, block_private_networks=False)
        claim = Claim(
            text="the reference pump is rated for a maximum operating pressure of 12 bar", domain="research_web"
        )
        ev = await adapter.gather_evidence(claim)

    assert len(ev) == 1, f"two near-identical mirror sources must count as ONE confirmation, got {len(ev)}"
    assert ev[0].stance == "supports"


async def test_multi_candidate_genuinely_different_sources_both_count():
    """Negative case for the same fix: two sources that are REALLY different
    text (different fixture pages, independently worded) confirming the same
    underlying fact must both be kept — that's real independent corroboration,
    which the near-duplicate guard must not throw away."""
    with serve_fixtures() as base_url:
        url_a = f"{base_url}/stable_page.html"
        url_b = f"{base_url}/stable_page_rephrased.html"
        rephrased_quote = "An independent test report confirmed the reference pump operates safely up to 12 bar without failure."

        async def fake_search(_query: str, _max: int) -> list[str]:
            return [url_a, url_b]

        client = _FakeClient(
            propose_by_marker={
                f"{url_a}#0": _found_json(f"{url_a}#0", _FIXTURE_QUOTE),
                f"{url_b}#0": _found_json(f"{url_b}#0", rephrased_quote),
            }
        )
        adapter = ResearchWebAdapter(client=client, search=fake_search, block_private_networks=False)
        claim = Claim(
            text="the reference pump is rated for a maximum operating pressure of 12 bar", domain="research_web"
        )
        ev = await adapter.gather_evidence(claim)

    assert len(ev) == 2, f"two genuinely different confirming sources should BOTH count, got {len(ev)}"
    assert {e.source for e in ev} == {url_a, url_b}
    assert all(e.stance == "supports" for e in ev)
